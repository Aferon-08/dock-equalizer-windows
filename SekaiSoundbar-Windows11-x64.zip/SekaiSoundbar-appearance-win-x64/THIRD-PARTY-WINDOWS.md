# Windows runtime components

This demo bundles dynamically linked Qt 6 runtime libraries/plugins and MinGW GCC runtime DLLs. The upstream Linux-reference dependencies listed in THIRD_PARTY.md are not all bundled or used by this demo. SekaiPOP, Quickshell, CAVA, Python, Node.js, FFmpeg and ML models are not required or included.

Qt upstream source: https://github.com/qt/qtbase, https://github.com/qt/qtdeclarative, https://github.com/qt/qtshadertools and https://github.com/qt/qtsvg. MinGW-w64: https://www.mingw-w64.org/ ; GCC: https://gcc.gnu.org/ .

App license: GPL-3.0 (LICENSE). Qt license texts and bundled third-party notices are in licenses/Qt. MinGW runtime copyright/license and GCC runtime-exception notices are in licenses/MinGW. Redistribution must include the applicable corresponding source and preserve these notices. This staging helper does not constitute a public release or a corresponding-source distribution.

The optional alignment launcher includes CPython 3.12.10 x64 from https://www.nuget.org/packages/python/3.12.10. Python and pip notices are in alignment/python. The CPU wheels, stable-ts, OpenAI Whisper, Whisper base checkpoint and FFmpeg are downloaded from their distributors during explicit setup. Their versions and checksums are in alignment.
